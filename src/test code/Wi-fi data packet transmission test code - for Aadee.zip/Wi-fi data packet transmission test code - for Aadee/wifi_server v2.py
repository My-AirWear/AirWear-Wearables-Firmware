import socket
import json
from datetime import datetime, timezone

HOST = "0.0.0.0"
PORT = 5000

print(f"AirWear receiver listening on port {PORT}...")

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind((HOST, PORT))
server.listen(1)

while True:
    print("Waiting for AirWear connection...")
    conn, addr = server.accept()
    print(f"Connected from {addr}")

    buffer = ""
    try:
        while True:
            data = conn.recv(1024).decode(errors="replace")
            if not data:
                print("Connection closed by device")
                break

            buffer += data

            while "\n" in buffer:
                line, buffer = buffer.split("\n", 1)
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                    ts = datetime.now().strftime("%H:%M:%S")
                    print(f"\n[{ts}]")
                    print(f"  PM1/PM2.5/PM10 : {record['pm1']} / {record['pm25']} / {record['pm10']} µg/m³")
                    print(f"  Obstructed     : {record['pm_obstructed']}")
                    print(f"  eCO2           : {record['eco2_ppm']} ppm")
                    print(f"  TVOC           : {record['tvoc_ppb']} ppb")
                    print(f"  AQI            : {record['aqi']} ({'OK' if record['ens_valid'] else 'Warming up'})")
                    if record['gps_valid']:
                        print(f"  Location       : {record['lat']:.6f}, {record['lon']:.6f}")
                        print(f"  Altitude       : {record['alt_m']:.1f}m  Speed: {record['speed_kmph']:.1f} km/h")
                        print(f"  Satellites     : {record['satellites']}")
                        gps_time = datetime.fromtimestamp(record['unix_time'], tz=timezone.utc)
                        print(f"  GPS time       : {gps_time.strftime('%Y-%m-%d %H:%M:%S')} UTC")
                    else:
                        print(f"  Location       : No GPS fix")
                except json.JSONDecodeError:
                    print(f"  Raw: {line}")

    except Exception as e:
        print(f"Connection error: {e}")
    finally:
        conn.close()