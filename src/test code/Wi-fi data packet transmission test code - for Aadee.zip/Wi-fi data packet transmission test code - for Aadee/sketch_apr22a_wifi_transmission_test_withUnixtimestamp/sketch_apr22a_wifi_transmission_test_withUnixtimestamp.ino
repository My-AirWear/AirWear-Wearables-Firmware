#include <WiFi.h>

const char* ssid     = "iPhone";
const char* password = "LIGHTNING88";
const char* host     = "172.20.10.2";
const uint16_t port  = 5000;

void setup() {
  Serial.begin(115200);
  delay(2000);

  Serial.println("Starting AirWear WiFi test...");
  WiFi.begin(ssid, password);

  unsigned long startAttempt = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - startAttempt < 15000) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("WiFi connected");
    Serial.print("ESP32 IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("WiFi FAILED");
    return;
  }

  WiFiClient client;
  Serial.println("Connecting to laptop...");

  if (client.connect(host, port)) {
    Serial.println("Connected to laptop server");

    // Send a realistic dummy JSON packet matching AirWear firmware format
    // unix_time is 0 since we have no GPS in this test sketch
    char json[768];
    snprintf(json, sizeof(json),
      "{"
      "\"millis\":%lu,"
      "\"pm1\":1.00,"
      "\"pm25\":2.00,"
      "\"pm10\":3.00,"
      "\"pm_obstructed\":false,"
      "\"eco2_ppm\":405,"
      "\"tvoc_ppb\":22,"
      "\"aqi\":1,"
      "\"ens_status\":2,"
      "\"ens_valid\":false,"
      "\"lat\":0.000000,"
      "\"lon\":0.000000,"
      "\"alt_m\":0.00,"
      "\"speed_kmph\":0.00,"
      "\"satellites\":0,"
      "\"gps_valid\":false,"
      "\"unix_time\":0"
      "}\n",
      (unsigned long)millis()
    );

    client.print(json);
    client.stop();
    Serial.println("JSON packet sent");
    Serial.print("Sent: ");
    Serial.println(json);
  } else {
    Serial.println("Failed to connect to laptop server");
  }
}

void loop() {
}